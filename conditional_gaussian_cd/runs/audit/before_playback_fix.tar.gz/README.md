# Conditional squeezing and conditional rotation from a pi-pulse train

**Start with `conditional_gaussian_gates.ipynb`.** Its first cell is the answer; every gate has its full pulse diagram,
programmed vs board I/Q, per-input errors and Wigner functions.

Model (coherent, ideal): resonant sideband g(e^{i psi} sigma+ a + h.c.), g = pi / (2 t_swap), on for the whole gate;
30 ns Hann qubit pi pulses (24 DAC samples at 800 MS/s) with phase phi; two-level qubit; no loss; no static chi.
A gate = N cells (half gap, pi pulse, half gap); the optimiser chooses the 2N phases. Fidelity = coherent gate fidelity
on the 18 inputs qubit g/e x Fock 0..8; one free qubit Rz after the gate.

| Gate (8 dB squeeze / pi-relative rotation) | swap | time | pi pulses, gap | F model | F board waveform |
|---|---|---|---|---|---|
| squeeze [0] | 600 ns | 7.61 us | 160, 17.5 ns | 99.930 % | 99.930 % |
| squeeze [1] | 600 ns | 6.73 us | 128, 22.5 ns | 99.687 % | 99.688 % |
| squeeze [2], constant sideband phase | 600 ns | 7.61 us | 160, 17.5 ns | 99.442 % | 99.444 % |
| squeeze [3] | 300 ns | 4.81 us | 160, 0 | 99.955 % | 99.955 % |
| rotation [4] | 600 ns | 8.81 us | 160, 25 ns | 99.968 % | 99.968 % |
| rotation [5] | 600 ns | 7.61 us | 160, 17.5 ns | 99.597 % | 99.597 % |
| rotation [6], constant sideband phase | 600 ns | 12.81 us | 256, 20 ns | 99.931 % | 99.929 % |
| rotation [7] | 300 ns | 4.81 us | 160, 0 | 99.983 % | 99.982 % |

Sequences: `runs/sequence_<n>.csv` (pulse, qubit phase, pump phase in degrees); int16 I/Q words: `runs/words_<n>.npz`;
apply the qubit Rz printed in the notebook after the gate.

## Faster conditional displacement (`fast_conditional_displacement.ipynb`)

CD(beta) = exp[beta sigma_x (a^dag - a)] on qubit g/e x Fock 0..10 (22 inputs), same model and 30 ns pi pulses.
Today's X X Xbar Xbar train (600 ns swap, 20 ns gaps) makes 1.28 beta/us: beta 1 in 0.81 us (99.81 %), beta 2 in
1.61 us (99.06 %). The same train at a 300 ns swap is 15-20x worse. With a 300 ns swap, back-to-back pi pulses and a
sideband phase per cell (all phases optimised): beta 1 in 0.49 us (99.66 %) or 0.73 us (99.93 %); beta 2 in 0.97 us
(99.33 %) or 1.45 us (99.93 %). Board-waveform checks agree to 3e-5. Sequences `runs/cd_sequence_<n>.csv`, words
`runs/cd_words_<n>.npz`; runs `runs/cd.json` (696 optimisations), `runs/cd_final.json`.

## Files

| File | What it is |
|---|---|
| `conditional_gaussian_gates.ipynb` | The study and the gates. Reads `runs/`; runs in a few minutes. |
| `cd_trains.py` | The model: one cell matrix, phases as diagonal conjugations, fidelity and its exact gradient, structured trains, waveform. |
| `optimise_trains.py` | All optimisations: `sweep`, `round2`, `round3`, `no_chi`, `final`; CD: `cd`, `cd_final` (L-BFGS-B, random starts, parallel). |
| `fast_conditional_displacement.ipynb` | The faster-CD study and its 8 gates. |
| `hardware_check.py` | Replays a gate through the SDK's 16-bit I/Q words and the RFDC 8x interpolation filter, integrated by `native_waveform_check.cpp`. |
| `cd_plots.py` | Pulse diagram, phase plot, programmed vs board I/Q, Wigner functions, squeezing / rotation measurement. |
| `runs/` | `sweep/round2/round3.json` (545 optimisations), `final.json` (the 8 gates), sequences, I/Q words, `all_runs.csv`. |

Re-run: `$ACADIA_ENV/bin/python optimise_trains.py sweep` (then `round2`, `round3`, `final`), then execute the notebook.

## History

* 2026-11-14 rebuild: Codex's earlier code (22 scripts, two notebooks, ~43,000-evaluation structured searches) replaced
  by the four files above; the new model reproduces Codex's saved gates to 1e-13 and its board-waveform replay exactly.
  Static chi removed at the user's request; all 545 optimisations then re-optimised without chi (warm-started).
  Earlier results with chi: `~/backups/cd_runs_with_chi_2026-11-14/`. Whole old folder:
  `~/backups/conditional_gaussian_cd_before_cleanup_2026-11-14.tar.gz`.
